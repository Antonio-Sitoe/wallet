# Wallet — UI do MVP — entire project

This project’s pages, files, and uploads as this browser tab had them at export.
Anything left out is listed below.

## Contents

### v1 · claro

- `Main.dc.html` — Painel
- `Orcamento.dc.html` — Orçamento — lista do mês
- `Plano.dc.html` — Plano anual
- `Transacoes.dc.html` — Transacções
- `Importar.dc.html` — Importar do Wallet

### v2 · dark macOS

- `Dark-Painel.dc.html` — Painel · dark
- `Dark-Orcamento.dc.html` — Orçamento · dark
- `Dark-Plano.dc.html` — Plano anual · dark
- `Dark-Transacoes.dc.html` — Transacções · dark
- `Dark-Importar.dc.html` — Importar · dark
- `Dark-Categorias.dc.html` — Categorias · dark
- `Dark-Contas.dc.html` — Contas
- `Dark-Definicoes.dc.html` — Definições
- `Dark-Tx-Detalhe.dc.html` — Transacção · detalhe, filtro e menu
- `Dark-Transferencia.dc.html` — Transferência ligada ao orçamento (variante do modal)
- `Dark-Orc-Check.dc.html` — Orçamento · confirmar item
- `Dark-Orc-Vazio.dc.html` — Orçamento · mês sem plano
- `Dark-Plano-Gerar.dc.html` — Plano · editar e gerar listas
- `Dark-Imp-1.dc.html` — Importar 1 · ficheiros
- `Dark-Imp-2.dc.html` — Importar 2 · contas
- `Dark-Imp-Folha.dc.html` — Importar 4 · folha 2026
- `Dark-Imp-Rever.dc.html` — Importar · rever 15 linhas
- `Dark-Imp-Fim.dc.html` — Importar 5 · concluído
- `Dark-Login.dc.html` — Entrar / criar conta
- `Dark-Onboarding.dc.html` — Primeiro uso
- `Dark-Estados.dc.html` — Estados: vazio, a carregar, erro, confirmação
- `Dark-Componentes.dc.html` — Tokens e componentes
- `Dark-Tx-Modal.dc.html` — Nova transacção · modal (⌘N, em todos os ecrãs)
- `Dark-Erro.dc.html` — Erro de ligação · ecrã inteiro
- `Dark-Cmdk.dc.html` — ⌘K · modo pesquisar
- `Dark-Cmdk-IA.dc.html` — ⌘K · modo perguntar (IA)
- `Dark-Chat.dc.html` — Assistente · chat com histórico e anexos (⌘J)
- `Dark-Metas.dc.html` — Metas · progresso, contribuir e nova meta
- `Dark-Dividas.dc.html` — Dívidas · por pessoa e pagamentos parciais
- `Dark-Pagamentos.dc.html` — Pagamentos planeados · próximos, atrasados, confirmar num clique

### Other files

- `canvas.json` — the canvas: its pages, where each artboard sits, its notes and shapes
- `_runtime/` — what runs the pages in a browser; not part of the design

## Viewing

To view a page, start a local web server in this folder (for example `python3 -m http.server`), then open an artboard’s `.dc.html` file through it. Opening the file directly may not work, because some browsers block its scripts.

## Left out of this export

The export never includes hidden files (files whose names start with a dot) or
files the editor keeps for its own use.
